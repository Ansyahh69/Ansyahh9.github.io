document.getElementById('startButton').addEventListener('click', function() {
    window.location.href = 'halaman2.html'; // Ganti 'halaman2.html' dengan URL halaman kedua Anda
});
