const questions = [
    {
        question: "Apa fungsi utama uang?",
        choices: ["Dekorasi", "Alat tukar", "Mainan", "Alat musik"],
        answer: "Alat tukar"
    },
    {
        question: "Mata uang apa yang digunakan di Amerika Serikat?",
        choices: ["Euro", "Yen", "Dolar", "Pound"],
        answer: "Dolar"
    },
    {
        question: "Apa nama mata uang Uni Eropa?",
        choices: ["Euro", "Dolar", "Pound", "Yen"],
        answer: "Euro"
    },
    {
        question: "Negara mana yang menggunakan Dinar sebagai mata uangnya?",
        choices: ["Bahrain", "Indonesia", "Jepang", "Amerika Serikat"],
        answer: "Bahrain"
    },
    {
        question: "Apa itu GDP per kapita?",
        choices: ["Pendapatan per orang", "Total utang pemerintah", "Inflasi tahunan", "Ekspor bersih"],
        answer: "Pendapatan per orang"
    },
    {
        question: "Apa fungsi dari uang sebagai penyimpan nilai?",
        choices: ["Menyimpan kekayaan", "Pembayaran pajak", "Dekorasi", "Media pertukaran"],
        answer: "Menyimpan kekayaan"
    },
    // ... Lanjutkan menambahkan semua pertanyaan yang telah diberikan sebelumnya
    {
        question: "Apa itu bear market?",
        choices: ["Pasar dengan tren naik", "Pasar dengan tren turun", "Pasar yang stabil", "Pasar hewan"],
        answer: "Pasar dengan tren turun"
    },
    {
        question: "Apa yang dimaksud dengan rating kredit?",
        choices: ["Skor untuk video game", "Penilaian terhadap kelayakan kredit peminjam", "Sistem penilaian untuk film", "Rating untuk aplikasi seluler"],
        answer: "Penilaian terhadap kelayakan kredit peminjam"
    }, 
    {
    question: "Apa itu obligasi pemerintah?",
    choices: ["Utang yang diterbitkan oleh perusahaan", "Investasi di pasar saham", "Utang yang diterbitkan oleh pemerintah", "Mata uang digital"],
    answer: "Utang yang diterbitkan oleh pemerintah"
    },
{
    question: "Negara manakah yang mata uangnya bernama Rand?",
    choices: ["Namibia", "Botswana", "Afrika Selatan", "Zimbabwe"],
    answer: "Afrika Selatan"
},
{
    question: "Apa itu portofolio investasi?",
    choices: ["Koleksi saham perusahaan", "Kumpulan investasi di berbagai instrumen keuangan", "Dokumen legal investasi", "Portofolio seni"],
    answer: "Kumpulan investasi di berbagai instrumen keuangan"
},
{
    question: "Apa itu utang publik?",
    choices: ["Total utang pribadi warga negara", "Total utang pemerintah daerah", "Total utang pemerintah pusat dan daerah", "Utang luar negeri negara"],
    answer: "Total utang pemerintah pusat dan daerah"
},
{
    question: "Apa yang dimaksud dengan pasar primer?",
    choices: ["Pasar tempat saham diperdagangkan pertama kali", "Pasar tempat membeli bahan primer", "Pasar untuk jual beli saham yang sudah ada", "Pasar untuk produk pertanian"],
    answer: "Pasar tempat saham diperdagangkan pertama kali"
},
{
    question: "Mata uang apa yang digunakan di China?",
    choices: ["Dinar", "Renminbi", "Yen", "Won"],
    answer: "Renminbi"
},
{
    question: "Apa itu IPO?",
    choices: ["Penjualan saham perusahaan kepada publik untuk pertama kalinya", "Investasi Pribadi Online", "Identifikasi Produk Online", "Instrumen Pembayaran Otomatis"],
    answer: "Penjualan saham perusahaan kepada publik untuk pertama kalinya"
},
{
    question: "Negara manakah yang menggunakan Shekel?",
    choices: ["Mesir", "Libanon", "Yordania", "Israel"],
    answer: "Israel"
},
{
    question: "Apa itu bear market?",
    choices: ["Pasar dengan tren naik", "Pasar dengan tren turun", "Pasar yang stabil", "Pasar hewan"],
    answer: "Pasar dengan tren turun"
},
{
    question: "Apa yang dimaksud dengan rating kredit?",
    choices: ["Skor untuk video game", "Penilaian terhadap kelayakan kredit peminjam", "Sistem penilaian untuk film", "Rating untuk aplikasi seluler"],
    answer: "Penilaian terhadap kelayakan kredit peminjam"
},
{
    question: "Mata uang apa yang digunakan di China?",
    choices: ["Renminbi", "Yen", "Won", "Dolar"],
    answer: "Renminbi"
},
{
    question: "Apa itu IPO?",
    choices: ["International Purchase Offer", "Initial Public Offering", "Immediate Payment Order", "Internal Profit Organization"],
    answer: "Initial Public Offering"
},
{
    question: "Negara manakah yang menggunakan Shekel?",
    choices: ["Iran", "Irak", "Israel", "Yordania"],
    answer: "Israel"
},
{
    question: "Apa itu bear market?",
    choices: ["Pasar dengan tren harga naik", "Pasar dengan tren harga stabil", "Pasar dengan tren harga menurun", "Pasar khusus jual beli beruang"],
    answer: "Pasar dengan tren harga menurun"
},
{
    question: "Apa yang dimaksud dengan rating kredit?",
    choices: ["Evaluasi kinerja kredit korporasi", "Penilaian kelayakan kredit individu atau perusahaan", "Sistem penghargaan untuk bank", "Skor untuk aplikasi kredit"],
    answer: "Penilaian kelayakan kredit individu atau perusahaan"
},
{
    question: "Apa itu bull market?",
    choices: ["Pasar dengan tren harga menurun", "Pasar dengan tren harga naik", "Pasar khusus jual beli banteng", "Pasar dengan fluktuasi harga minim"],
    answer: "Pasar dengan tren harga naik"
},
{
    question: "Apa itu diversifikasi dalam investasi?",
    choices: ["Investasi di satu aset untuk mengurangi risiko", "Pembagian investasi di berbagai aset untuk mengurangi risiko", "Investasi semua modal di saham", "Pembelian satu jenis obligasi saja"],
    answer: "Pembagian investasi di berbagai aset untuk mengurangi risiko"
},
{
    question: "Negara mana yang mata uangnya disebut Kuna?",
    choices: ["Slovenia", "Kroasia", "Serbia", "Montenegro"],
    answer: "Kroasia"
},
{
    question: "Apa yang dimaksud dengan pajak langsung?",
    choices: ["Pajak yang dibayar langsung ke pemerintah oleh konsumen", "Pajak yang dibebankan pada pembelian barang dan jasa", "Pajak yang dibayar melalui perantara", "Pajak atas pendapatan atau harta"],
    answer: "Pajak atas pendapatan atau harta"
},
{
    question: "Mata uang apa yang digunakan di Australia?",
    choices: ["Dolar Australia", "Pound Australia", "Euro Australia", "Dolar"],
    answer: "Dolar Australia"
},
{
    question: "Apa itu nilai tukar mengambang?",
    choices: ["Nilai tukar yang ditetapkan oleh pemerintah", "Nilai tukar yang ditentukan oleh pasar", "Nilai tukar tetap untuk semua mata uang", "Nilai tukar yang tidak pernah berubah"],
    answer: "Nilai tukar yang ditentukan oleh pasar"
},
{
    question: "Apa itu bailout?",
    choices: ["Proses untuk menaikkan harga saham", "Bantuan finansial untuk mencegah kebangkrutan", "Pengenaan pajak baru oleh pemerintah", "Pembelian saham oleh perusahaan besar"],
    answer: "Bantuan finansial untuk mencegah kebangkrutan"
},
{
    question: "Negara manakah yang menggunakan Lira?",
    choices: ["Yunani", "Turki", "Italia", "Spanyol"],
    answer: "Turki"
},
{
    question: "Apa yang dimaksud dengan pasar obligasi?",
    choices: ["Pasar untuk jual beli mata uang", "Pasar untuk jual beli saham", "Pasar untuk jual beli utang", "Pasar untuk jual beli properti"],
    answer: "Pasar untuk jual beli utang"
},
{
    question: "Apa itu defisit perdagangan?",
    choices: ["Ketika impor lebih besar dari ekspor", "Ketika ekspor lebih besar dari impor", "Ketika impor sama dengan ekspor", "Ketika ekspor dan impor tidak mempengaruhi ekonomi"],
    answer: "Ketika impor lebih besar dari ekspor"
},
{
    question: "Mata uang apa yang digunakan di Brasil?",
    choices: ["Dolar Brasil", "Real", "Peso", "Euro"],
    answer: "Real"
},
{
    question: "Apa itu bank sentral?",
    choices: ["Bank komersial terbesar di sebuah negara", "Lembaga yang mengatur uang beredar dan suku bunga", "Bank yang memberikan pinjaman tanpa bunga", "Bank khusus untuk pemerintah"],
    answer: "Lembaga yang mengatur uang beredar dan suku bunga"
},
{
    question: "Apa itu depresi ekonomi?",
    choices: ["Penurunan ringan aktivitas ekonomi", "Penurunan tajam dan berkepanjangan dalam aktivitas ekonomi", "Kenaikan cepat dalam aktivitas ekonomi", "Stabilitas total dalam aktivitas ekonomi"],
    answer: "Penurunan tajam dan berkepanjangan dalam aktivitas ekonomi"
},
{
    question: "Negara mana yang mata uangnya disebut Rupiah?",
    choices: ["Indonesia", "Malaysia", "Thailand", "Filipina"],
    answer: "Indonesia"
},
{
    question: "Apa yang dimaksud dengan inflasi deflationer?",
    choices: ["Kenaikan umum harga-harga", "Penurunan umum harga-harga", "Stabilitas harga-harga", "Fluktuasi harga secara ekstrem"],
    answer: "Penurunan umum harga-harga"
},
{
    question: "Apa itu cryptocurrency?",
    choices: ["Mata uang berbasis emas", "Mata uang digital", "Mata uang cetak", "Mata uang konvensional"],
    answer: "Mata uang digital"
},
{
    question: "Negara manakah yang menggunakan Franc CFA?",
    choices: ["Maroko", "Algeria", "Senegal", "Mesir"],
    answer: "Senegal"
},
{
    question: "Apa itu neraca perdagangan?",
    choices: ["Nilai ekspor dikurangi impor", "Total utang negara", "Total nilai mata uang dicetak", "Jumlah produk domestik bruto"],
    answer: "Nilai ekspor dikurangi impor"
},
{
    question: "Mata uang apa yang digunakan di Rusia?",
    choices: ["Yuan", "Rubel", "Dolar", "Euro"],
    answer: "Rubel"
},
{
    question: "Apa itu saham preferen?",
    choices: ["Saham tanpa hak suara", "Saham dengan dividen tetap", "Saham yang dapat ditukar", "Saham biasa"],
    answer: "Saham dengan dividen tetap"
},
{
    question: "Siapa yang menetapkan kebijakan moneter di AS?",
    choices: ["Kongres AS", "Presiden AS", "Federal Reserve", "Bank Dunia"],
    answer: "Federal Reserve"
}, 
    {
        question: "Sebutkan contoh uang yang pernah digunakan sebagai alat tukar sejarah!",
        choices: ["Uang kertas dan kartu kredit", "Bitcoin dan Ethereum", "Emas dan perak", "Kartu debit dan cek"],
        correctAnswer: "Emas dan perak"
    },
    {
        question: "Sebutkan contoh uang kertas denominasi kecil di Indonesia!",
        choices: ["Uang lima rupiah", "Uang seribu rupiah", "Uang seratus rupiah", "Uang lima puluh ribu rupiah"],
        correctAnswer: "Uang seribu rupiah"
    },
    {
        question: "Dalam menjaga kelancaran sistem pembayaran pemerintah membentuk suatu lembaga yang diberikan hak mengatur dan menjaga sistem pembayaran. Lembaga tersebut adalah …..",
        choices: ["OJK", "Kementerian Keuangan", "Bank Indonesia", "LPS"],
        correctAnswer: "Bank Indonesia"
    },
    {
        question: "Kebijakan yang dilakukan bank central dalam istilah ekonomi disebut dengan kebijakan moneter yaitu kebijakan menjaga jumlah uang yang beredar di masyarakat. Salah satunya adalah dengan cara menaikkan atau menurunkan tingkat suku bunga yang berlaku di bank-bank umum. Kebijakan ini disebut dengan …..",
        choices: ["Kebijakan fiskal", "Kebijakan diskonto", "Kebijakan perdagangan", "Kebijakan subsidi"],
        correctAnswer: "Kebijakan diskonto"
    },
    {
        question: "Uang yang kita gunakan sehari-hari adalah uang …..",
        choices: ["Giral", "Kartal", "Kripto", "Virtual"],
        correctAnswer: "Kartal"
    },
    {
        question: "Suatu peristiwa yang terjadi pada krisis moneter yang terjadi tahun 1998 melonjaknya harga – harga kebutuhan pokok, investor asing takut menanamkan modalnya di Indonesia, dan kecenderungan orang menyimpan uang di bank sangat rendah. Kejadian tersebut sebenarnya merupakan dampak dari …..",
        choices: ["Deflasi", "Inflasi", "Stagflasi", "Hiperinflasi"],
        correctAnswer: "Inflasi"
    },
    {
        question: "Benda yang diterima secara umum dapat digunakan sebagai alat tukar, dan dapat digunakan sebagai alat pembayaran, disebut …..",
        choices: ["Barang", "Jasa", "Uang", "Saham"],
        correctAnswer: "Uang"
    },
    {
        question: "Apa nama mata uang dari Myanmar?",
        choices: ["Kyat", "Baht", "Rupiah", "Dong"],
        correctAnswer: "Kyat"
    },
    {
        question: "Negara manakah yang menggunakan mata uang manat?",
        choices: ["Kazakhstan", "Turkmenistan", "Azerbaijan", "Uzbekistan"],
        correctAnswer: "Azerbaijan"
    },
    {
        question: "Negara manakah yang menggunakan mata uang zloty?",
        choices: ["Czech Republic", "Slovakia", "Polandia", "Hungaria"],
        correctAnswer: "Polandia"
    }, 
    
];

let currentLevel = 1;
let score =0 ;

function getRandomQuestion() {
    return questions[Math.floor(Math.random() * questions.length)];
}

function displayQuestion() {
  if (currentLevel > 20) {
    // Simpan skor akhir ke localStorage untuk diakses di halaman ke-5
    localStorage.setItem("finalScore", score);

    // Arahkan ke halaman ke-5
    window.location.href = 'halaman5.html';
}

    const questionObj = getRandomQuestion();
    const questionEl = document.getElementById("question");
    const choicesForm = document.getElementById("choicesForm");
    questionEl.innerText = `Level ${currentLevel}: ${questionObj.question}`;

    choicesForm.innerHTML = '';

    questionObj.choices.forEach(choice => {
        const label = document.createElement("label");
        label.innerHTML = `<input type="radio" name="choice" value="${choice}"> ${choice}`;
        choicesForm.appendChild(label);
    });
}

function checkAnswer() {
    const selectedChoice = document.querySelector('input[name="choice"]:checked');
    if (!selectedChoice) return alert("Please select an answer.");

    const questionText = document.getElementById("question").innerText;
    const correctAnswer = questions.find(q => `Level ${currentLevel}: ${q.question}` === questionText).answer;

    if (selectedChoice.value === correctAnswer) {
        score += 5; 
        currentLevel++;
        alert(`Correct! Your score is now ${score}.`);
    } else {
        alert(`Wrong! The correct answer is "${correctAnswer}". You're back to level 1 with score 0.`);
        resetGame();
    }

    if (currentLevel <= 20) {
        displayQuestion(); 
    } else {
        alert(`Congratulations! You've completed all levels. Final score: ${score}`);
        resetGame();
    }
}

function skipLevel() {
    currentLevel++;
    if (currentLevel > 20) {
        alert(`Congratulations! You've reached the end of the game. Final score: ${score}`);
        resetGame();
    } else {
        displayQuestion(); 
    }
}

document.getElementById("skipBtn").addEventListener("click", function(event) {
    event.preventDefault(); 
    skipLevel();
});


function resetGame() {
    currentLevel = 1;
    score = 0;
    displayQuestion();
}

document.getElementById("submitBtn").addEventListener("click", function(event) {
    event.preventDefault();
    checkAnswer();
});

window.onload = displayQuestion;
